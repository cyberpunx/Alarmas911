-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 09-09-2015 a las 15:00:53
-- Versión del servidor: 5.6.12-log
-- Versión de PHP: 5.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `alarmas_db`
--
CREATE DATABASE IF NOT EXISTS `alarmas_db` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `alarmas_db`;

--
-- Truncar tablas antes de insertar `accesorios`
--

TRUNCATE TABLE `accesorios`;
--
-- Volcado de datos para la tabla `accesorios`
--

INSERT INTO `accesorios` (`accesorio_id`, `modelos_modelo_id`, `baterias_bateria_id`, `sistema_alarmas_sistema_alarma_id`, `nombre_accesorio`, `observaciones_accesorio`) VALUES
(4, 13, NULL, 8, 'Sirena principal', ''),
(5, 9, NULL, 9, 'Sirena entrada', ''),
(6, 8, NULL, 10, 'Sirena entrada', ''),
(7, 11, NULL, 11, 'Sirena', ''),
(8, 6, NULL, 12, 'Sirena', ''),
(9, 5, NULL, 13, 'Sirena', ''),
(10, 5, NULL, 14, 'Sirena entrada', ''),
(11, 6, NULL, 14, 'Sirena alarma humo', '');

--
-- Truncar tablas antes de insertar `barrios`
--

TRUNCATE TABLE `barrios`;
--
-- Volcado de datos para la tabla `barrios`
--

INSERT INTO `barrios` (`barrio_id`, `nombre_barrio`, `observaciones_barrio`) VALUES
(1, 'Centro', 'Radio céntrico'),
(2, 'Melipal', 'Km 4'),
(3, 'Los Coihues', NULL),
(4, 'Casa de Piedra', 'Km 12'),
(5, 'Frutillar', ''),
(6, '400 Viviendas', ''),
(7, 'Virgen Misionera', ''),
(8, 'Pinar de Festa', ''),
(9, 'Los Coihues', '');

--
-- Truncar tablas antes de insertar `baterias`
--

TRUNCATE TABLE `baterias`;
--
-- Volcado de datos para la tabla `baterias`
--

INSERT INTO `baterias` (`bateria_id`, `sistema_alarmas_sistema_alarma_id`, `modelos_modelo_id`, `tipos_baterias_tipo_bateria_id`, `observaciones_bateria`, `vida_util`, `fecha_alta`, `fecha_baja`) VALUES
(3, 8, 18, 1, '', 1, '2015-08-11', NULL),
(4, 9, 11, 3, '', 3, '2015-02-01', NULL),
(5, 10, 7, 2, '', 2, '2015-06-16', NULL),
(6, 11, 6, 2, '', 3, '2014-12-03', NULL),
(7, 12, 6, 1, '', 3, '2015-09-09', NULL),
(8, 13, 8, 1, '', 1, '2014-06-03', NULL),
(9, 14, 6, 1, '', 1, '2015-06-24', NULL);

--
-- Truncar tablas antes de insertar `detalle_ordenes_servicio`
--

TRUNCATE TABLE `detalle_ordenes_servicio`;
--
-- Volcado de datos para la tabla `detalle_ordenes_servicio`
--

INSERT INTO `detalle_ordenes_servicio` (`detalle_orden_servicio_id`, `ordenes_servicio_orden_servicio_id`, `tipos_servicio_tipo_servicio_id`, `descripcion_detalle_orden_servicio`) VALUES
(31, 16, 3, 'instalación del sistema'),
(34, 14, 3, 'instalación del sistema'),
(37, 15, 3, 'instalación del sistema'),
(40, 17, 3, 'instalación del sistema'),
(41, 18, 3, 'instalación del sistema'),
(44, 19, 3, 'instalación del sistema'),
(45, 20, 3, 'instalación del sistema'),
(46, 21, 1, 'reparación sensor'),
(47, 22, 3, 'Inst. sensor'),
(48, 22, 6, 'Sensor movimiento'),
(49, 23, 2, ''),
(50, 23, 6, 'bateria'),
(51, 24, 6, 'Sensor Barrera'),
(52, 24, 6, 'Sensor movimiento'),
(53, 25, 1, 'reemplazo sirena'),
(54, 25, 6, 'sirena'),
(55, 26, 2, 'nueva batería'),
(56, 27, 3, 'instalación panel'),
(57, 27, 6, 'panel');

--
-- Truncar tablas antes de insertar `marcas`
--

TRUNCATE TABLE `marcas`;
--
-- Volcado de datos para la tabla `marcas`
--

INSERT INTO `marcas` (`marca_id`, `nombre_marca`, `observaciones_marca`) VALUES
(1, 'YAMAHA', NULL),
(2, 'Steinway and Sons', NULL),
(3, 'KAWAI', NULL),
(4, 'Bechstein', NULL),
(5, 'Bosendorfer', NULL),
(6, 'Fender', NULL),
(7, 'Gibson', NULL),
(8, 'Ibanez', NULL),
(9, 'Mapex', ''),
(10, 'Pearl', ''),
(11, 'Zildjian', '');

--
-- Truncar tablas antes de insertar `modelos`
--

TRUNCATE TABLE `modelos`;
--
-- Volcado de datos para la tabla `modelos`
--

INSERT INTO `modelos` (`modelo_id`, `marcas_marca_id`, `nombre_modelo`, `observaciones_modelo`, `discriminante`) VALUES
(1, 6, 'Stratocaster', NULL, ''),
(2, 6, 'Telecaster', NULL, ''),
(3, 6, 'Jazzmaster', NULL, ''),
(4, 7, 'Les Paul', NULL, ''),
(5, 7, 'SG', NULL, ''),
(6, 7, 'Explorer', NULL, ''),
(7, 8, 'Gio', NULL, ''),
(8, 1, 'C5X', NULL, ''),
(9, 2, 'Concert Grand Model D', NULL, ''),
(10, 3, 'GX-7', 'GX-7 – 7''6" Semi-Concert Grand Piano', ''),
(11, 3, 'K-800', '53" Professional Upright Piano', ''),
(12, 2, 'Model 1098', 'Studio Upright', ''),
(13, 8, 'RG', '', ''),
(14, 8, 'Iceman', '', ''),
(15, 1, 'GC2 Grand Piano', '', ''),
(16, 4, 'B 228', '', ''),
(17, 5, 'Model 120 CL', '', ''),
(18, 9, 'Horizon', '', ''),
(19, 9, 'Voyager', '', ''),
(20, 10, 'Vision', '', ''),
(21, 10, 'Session', '', ''),
(22, 11, 'Scimitar', '', ''),
(23, 11, 'Amir', '', '');

--
-- Truncar tablas antes de insertar `ordenes_servicio`
--

TRUNCATE TABLE `ordenes_servicio`;
--
-- Volcado de datos para la tabla `ordenes_servicio`
--

INSERT INTO `ordenes_servicio` (`orden_servicio_id`, `fecha_emision`, `fecha_cierre`, `importe`, `observaciones_orden_servicio`, `vencimiento_orden`, `prioridad`, `sistema_alarmas_sistema_alarma_id`) VALUES
(14, '2014-07-01', '2014-07-01', 1200, 'instalacion', '0000-00-00', 1, 10),
(15, '2013-10-01', '2013-10-01', 1500, 'instalación', '0000-00-00', 0, 8),
(16, '2015-04-01', '2015-04-03', 1000, 'instalacion', '2015-05-01', 1, 12),
(17, '2013-01-16', '2013-01-16', 800, 'instalacion del sistema', '0000-00-00', 0, 11),
(18, '2014-08-20', '2014-08-20', 1100, 'instalacion', '0000-00-00', 0, 14),
(19, '2012-09-09', '2012-09-09', 900, 'instalacion', '0000-00-00', 0, 9),
(20, '2012-09-09', '2012-09-09', 1200, 'instalacion', '0000-00-00', 2, 14),
(21, '2014-10-15', '2014-10-15', 200, 'reparaciones', '2014-10-18', 2, 14),
(22, '2015-05-07', '2015-05-07', 600, 'Cambio de sensor urgente', '2015-05-07', 1, 10),
(23, '2015-09-09', '2015-09-12', 900, 'cambio baterias', '2015-09-16', 2, 13),
(24, '2015-05-27', '2015-05-27', 450, 'venta sensores', '2015-05-27', 1, 13),
(25, '2015-04-24', '2015-05-04', 900, 'reparaciones', '2015-05-04', 2, 8),
(26, '2015-05-12', '2015-05-12', 200, 'cambio batería', '0000-00-00', 0, 9),
(27, '2015-04-22', '2015-04-22', 850, 'nuevo panel', '0000-00-00', 0, 11);

--
-- Truncar tablas antes de insertar `pagos`
--

TRUNCATE TABLE `pagos`;
--
-- Volcado de datos para la tabla `pagos`
--

INSERT INTO `pagos` (`pago_id`, `usuarios_usuario_id`, `importe`, `ordenes_servicio_orden_servicio_id`, `fecha`, `tipos_pago_tipo_pago_id`, `informacion_pago`) VALUES
(6, 3, 2600, NULL, '2015-09-01', 1, 'Nro. Fact. 02598451321'),
(7, 4, 200, NULL, '2015-05-13', 7, 'transferencia'),
(8, 4, 900, NULL, '2012-09-09', 1, 'Nro. Fact. 02598451321'),
(9, 5, 600, NULL, '2015-05-07', 1, ''),
(10, 5, 850, NULL, '2015-04-22', 2, ''),
(11, 5, 1200, NULL, '2014-07-01', 5, ''),
(12, 5, 800, NULL, '2013-01-16', 5, ''),
(13, 6, 1000, NULL, '2015-04-01', 2, ''),
(14, 7, 2000, NULL, '2015-09-09', 7, ''),
(15, 8, 1000, NULL, '2012-09-09', 7, ''),
(16, 8, 1200, NULL, '2014-08-20', 7, '');

--
-- Truncar tablas antes de insertar `paneles`
--

TRUNCATE TABLE `paneles`;
--
-- Volcado de datos para la tabla `paneles`
--

INSERT INTO `paneles` (`panel_id`, `baterias_bateria_id`, `modelos_modelo_id`, `sistema_alarmas_sistema_alarma_id`, `nombre_panel`, `observaciones_panel`) VALUES
(4, NULL, 16, 8, 'Panel Entrada', ''),
(5, NULL, 10, 9, 'Panel trastienda', ''),
(6, NULL, 6, 10, 'Panel Entrada', ''),
(7, NULL, 8, 11, 'Panel Living', ''),
(8, NULL, 6, 12, 'Panel Entrada', ''),
(9, NULL, 8, 13, 'Panel Living', ''),
(10, NULL, 4, 14, 'Panel cocina', '');

--
-- Truncar tablas antes de insertar `sensores`
--

TRUNCATE TABLE `sensores`;
--
-- Volcado de datos para la tabla `sensores`
--

INSERT INTO `sensores` (`sensor_id`, `baterias_bateria_id`, `tipos_sensores_tipo_sensor_id`, `modelos_modelo_id`, `zonas_zona_id`) VALUES
(14, NULL, 1, 8, 22),
(15, NULL, 3, 15, 22),
(17, NULL, 3, 8, 23),
(18, NULL, 11, 17, 23),
(19, NULL, 1, 19, 24),
(20, NULL, 6, 9, 24),
(21, NULL, 4, 4, 25),
(22, NULL, 4, 8, 25),
(23, NULL, 4, 15, 25),
(24, NULL, 6, 13, 25),
(25, NULL, 3, 16, 25),
(26, NULL, 1, 8, 26),
(27, NULL, 3, 17, 26),
(28, NULL, 6, 18, 27),
(29, NULL, 4, 15, 28),
(30, NULL, 11, 17, 29),
(31, NULL, 6, 17, 29),
(32, NULL, 7, 15, 29),
(33, NULL, 9, 18, 30),
(34, NULL, 9, 17, 31),
(35, NULL, 5, 13, 31),
(36, NULL, 1, 11, 32),
(38, NULL, 3, 15, 33),
(39, NULL, 10, 15, 33);

--
-- Truncar tablas antes de insertar `sistema_alarmas`
--

TRUNCATE TABLE `sistema_alarmas`;
--
-- Volcado de datos para la tabla `sistema_alarmas`
--

INSERT INTO `sistema_alarmas` (`sistema_alarma_id`, `nombre_sistema_alarma`, `observaciones_sistema_alarma`, `barrios_barrio_id`, `tipos_monitoreo_tipo_monitoreo_id`, `modelos_modelo_id`, `usuarios_usuario_id`) VALUES
(8, 'Goodwin - Sistema', 'Bariloche Center - 4to piso.', 1, 1, 22, 3),
(9, 'Ramirez R. - Sistema', 'Local', 1, 2, 20, 4),
(10, 'Good - SISTEMA NEGOCIO', 'Local de ropa', 1, 2, 4, 5),
(11, 'Good M. - SISTEMA CASA', '', 2, 1, 7, 5),
(12, 'Floyd A. / KIOSCO', '', 5, 1, 4, 6),
(13, 'Fox G. Sistema', '', 3, 3, 1, 7),
(14, 'Lynn H. Sistema', '', 8, 1, 4, 8);

--
-- Truncar tablas antes de insertar `tipos_baterias`
--

TRUNCATE TABLE `tipos_baterias`;
--
-- Volcado de datos para la tabla `tipos_baterias`
--

INSERT INTO `tipos_baterias` (`tipo_bateria_id`, `nombre`, `observaciones`) VALUES
(1, 'Energizer', NULL),
(2, 'Eveready', NULL),
(3, 'Duracell', NULL);

--
-- Truncar tablas antes de insertar `tipos_cliente`
--

TRUNCATE TABLE `tipos_cliente`;
--
-- Volcado de datos para la tabla `tipos_cliente`
--

INSERT INTO `tipos_cliente` (`tipo_cliente_id`, `nombre_tipo_cliente`, `observaciones_tipo_cliente`) VALUES
(1, 'Default', NULL),
(3, 'Cliente VIP', ''),
(4, 'Ex - Cliente', '');

--
-- Truncar tablas antes de insertar `tipos_monitoreo`
--

TRUNCATE TABLE `tipos_monitoreo`;
--
-- Volcado de datos para la tabla `tipos_monitoreo`
--

INSERT INTO `tipos_monitoreo` (`tipo_monitoreo_id`, `nombre_tipo_monitoreo`, `valor`) VALUES
(1, 'Sin Monitoreo', NULL),
(2, 'Full Monitoreo', NULL),
(3, 'Monitoreo externo', 250);

--
-- Truncar tablas antes de insertar `tipos_pago`
--

TRUNCATE TABLE `tipos_pago`;
--
-- Volcado de datos para la tabla `tipos_pago`
--

INSERT INTO `tipos_pago` (`tipo_pago_id`, `nombre_tipo_pago`, `observaciones_tipo_pago`) VALUES
(1, 'Efectivo', NULL),
(2, 'Débito', NULL),
(3, 'Cheque', ''),
(4, 'Tarjeta Crédito - Mastercard', ''),
(5, 'Tarjeta Crédito - Naranja', ''),
(6, 'Tarjeta Crédito', ''),
(7, 'Transferencia', '');

--
-- Truncar tablas antes de insertar `tipos_sensores`
--

TRUNCATE TABLE `tipos_sensores`;
--
-- Volcado de datos para la tabla `tipos_sensores`
--

INSERT INTO `tipos_sensores` (`tipo_sensor_id`, `nombre_sensor`, `observaciones_sensor`) VALUES
(1, 'Movimiento', NULL),
(2, 'Movimiento Anti Mascotas', NULL),
(3, 'Puerta - Abertura', ''),
(4, 'Ventana - Abertura', ''),
(5, 'Barrera', ''),
(6, 'Magnético - Abertura', ''),
(7, 'Movimiento - Inalámbrico', ''),
(8, 'Movimiento - Infrarrojo', ''),
(9, 'Barrera - Infrarrojo', ''),
(10, 'Sensor de Humo', ''),
(11, 'Sensor Rotura', '');

--
-- Truncar tablas antes de insertar `tipos_servicio`
--

TRUNCATE TABLE `tipos_servicio`;
--
-- Volcado de datos para la tabla `tipos_servicio`
--

INSERT INTO `tipos_servicio` (`tipo_servicio_id`, `nombre_tipo_servicio`, `observaciones_tipo_servicio`) VALUES
(1, 'Reparaciones', 'Reparacion de sensores, sirenas, central, etc'),
(2, 'Cambio de Baterías', 'Cambio de baterías'),
(3, 'Instalación', 'Instalación de componentes'),
(4, 'Cobro Monitoreo', ''),
(5, 'Otro (especificar)', ''),
(6, 'Venta', '');

--
-- Truncar tablas antes de insertar `usuarios`
--

TRUNCATE TABLE `usuarios`;
--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`usuario_id`, `nombre`, `apellido`, `email`, `password`, `direccion`, `dni`, `telefono_celular`, `telefono_fijo`, `telefono_alt`, `rol`, `comentarios`, `empleado_funcion`, `empleado_temporal`, `empleado_activo`, `cliente_direccion_cobro`, `cliente_sistema_secundario_id`, `cliente_factura`, `cliente_razon_social`, `cliente_cuit`, `tipos_cliente_tipo_cliente_id`) VALUES
(1, 'admin', 'admin', 'admin', 'admin', '', 123, '', '', '', 'ADMINISTRADOR', '', '', 0, 0, '', NULL, '', '', NULL, 1),
(3, 'Emerson', 'Goodwin', 'augue@senectuset.org', 'test', '159 Ipsum. Street', 13465115, '294 4236473', '294 429362', '', 'CLIENTE', 'Sed id risus quis diam luctus lobortis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos. Mauris ut quam vel sapien imperdiet ornare. In faucibus. Morbi vehicula. Pellentesque', '', 0, 0, '7537 Nunc St.', 624, 'A', 'Risus Incorporated', 7017042, 1),
(4, 'Rudyard', 'Ramirez', 'Nullam.nisl@estNuncullamcorper.net', 'test', '2437 Lorem, Ave', 83454649, '294 4703374', '294 460064', '', 'CLIENTE', 'morbi tristique senectus et netus et malesuada fames ac turpis egestas. Fusce aliquet magna a neque. Nullam ut nisi a odio semper cursus. Integer mollis. Integer tincidunt aliquam arcu. Aliquam ultrices iaculis odio. Nam interdum enim non nisi. Aenean eget metus. In nec orci. Donec nibh. Quisque nonummy ipsum non', NULL, NULL, NULL, 'P.O. Box 193, 6817 Pede, Av.', 82, 'A', 'Velit Pellentesque Industries', 18443133, 1),
(5, 'Melvin', 'Good', 'nonummy@Aliquam.co.uk', 'test', '808-8882 Fringilla St.', 28336062, '294 4630621', '294 430716', '', 'CLIENTE', 'dapibus id, blandit at, nisi. Cum sociis natoque penatibus et magnis dis parturient', NULL, NULL, NULL, '440-3397 Proin St.', 595, 'A', 'Condimentum Donec LLP', 54608663, 1),
(6, 'Ashton', 'Floyd', 'Vivamus@sitamet.org', 'test', '3555 Mattis. Ave', 10093954, '294 4774137', '294 482244', '', 'CLIENTE', 'odio. Phasellus at augue id ante dictum cursus. Nunc mauris elit, dictum eu, eleifend nec, malesuada ut, sem. Nulla interdum. Curabitur dictum. Phasellus in felis. Nulla tempor augue ac ipsum. Phasellus vitae mauris sit amet lorem semper auctor. Mauris vel turpis. Aliquam adipiscing lobortis risus. In mi pede, nonummy ut, molestie in, tempus eu, ligula. Aenean euismod mauris eu elit. Nulla facilisi. Sed neque. Sed eget lacus. Mauris non dui nec urna suscipit nonummy. Fusce fermentum fermentum arcu. Vestibulum ante ipsum primis in faucibus orci', NULL, NULL, NULL, 'P.O. Box 533, 4474 Est. Street', 307, 'A', 'Aliquam Associates', 22777905, 1),
(7, 'Gloria', 'Fox', 'ultrices.sit.amet@maurisut.org', 'test', '709-2346 Elementum, Street', 32535267, '294 4292391', '294 473026', '', 'CLIENTE', 'urna justo faucibus lectus, a sollicitudin orci sem eget massa. Suspendisse eleifend. Cras sed leo. Cras vehicula aliquet libero. Integer in magna. Phasellus dolor elit, pellentesque a, facilisis non, bibendum sed, est. Nunc laoreet lectus quis massa. Mauris vestibulum,', NULL, NULL, NULL, 'P.O. Box 494, 7352 Tristique Street', 827, 'A', 'Eget Magna Institute', 42508716, 1),
(8, 'Hope', 'Lynn', 'Phasellus.dapibus.quam@anteipsumprimis.edu', 'test', 'P.O. Box 850, 2554 Nulla. St.', 53265100, '294 4449613', '294 437108', '', 'CLIENTE', 'ipsum leo elementum sem, vitae aliquam eros', NULL, NULL, NULL, '5727 Non, Avenue', 310, 'A', 'Eget Metus Eu Incorporated', 11239113, 1),
(9, 'Latifah', 'Gallagher', 'eget.tincidunt.dui@quis.org', 'test', '985-3867 Parturient St.', 80198045, '294 4617493', '294 426682', '', 'CLIENTE', 'Nullam vitae diam. Proin dolor. Nulla semper tellus id nunc interdum feugiat. Sed nec metus facilisis lorem tristique aliquet. Phasellus fermentum convallis ligula. Donec luctus aliquet odio. Etiam ligula tortor, dictum eu, placerat eget, venenatis a, magna. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Etiam laoreet, libero et tristique pellentesque, tellus sem mollis dui, in sodales elit erat vitae risus. Duis a mi fringilla mi lacinia mattis. Integer eu lacus. Quisque imperdiet, erat nonummy ultricies ornare, elit elit fermentum risus, at fringilla purus mauris a nunc. In at', NULL, NULL, NULL, '4685 Nunc Ave', 62, 'A', 'Libero Morbi Company', 68290718, 1),
(10, 'Mona', 'West', 'lacus@vitaeeratVivamus.co.uk', 'test', 'P.O. Box 794, 5816 Nunc St.', 11241015, '294 4029755', '294 442217', '', 'CLIENTE', 'per conubia nostra, per inceptos hymenaeos. Mauris ut quam vel sapien imperdiet ornare. In faucibus. Morbi vehicula. Pellentesque tincidunt tempus risus. Donec egestas. Duis ac', NULL, NULL, NULL, 'P.O. Box 762, 5514 Et St.', 197, 'A', 'Ac Orci LLP', 22179052, 1),
(11, 'Tucker', 'Merritt', 'Suspendisse@egetmetus.co.uk', 'test', '8208 Urna Rd.', 89560972, '294 4681497', '294 488302', '', 'CLIENTE', 'mauris eu elit. Nulla facilisi. Sed neque. Sed eget lacus. Mauris non dui nec urna suscipit nonummy. Fusce fermentum fermentum arcu. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae Phasellus ornare. Fusce mollis. Duis sit amet diam eu', NULL, NULL, NULL, '8222 Adipiscing Av.', 602, 'A', 'Faucibus Lectus Ltd', 13989670, 1),
(12, 'Gisela', 'Owens', 'venenatis@acorciUt.ca', 'test', '8105 Ipsum. St.', 44602591, '294 4682129', '294 420962', '', 'CLIENTE', 'arcu. Vivamus sit amet risus. Donec egestas. Aliquam nec enim. Nunc ut erat. Sed nunc est, mollis non, cursus non, egestas a, dui. Cras pellentesque. Sed dictum. Proin eget odio. Aliquam vulputate ullamcorper magna. Sed eu eros. Nam consequat dolor vitae dolor. Donec fringilla. Donec feugiat metus sit amet ante. Vivamus non lorem vitae odio sagittis semper. Nam tempor diam dictum sapien. Aenean massa. Integer vitae nibh. Donec est mauris, rhoncus', NULL, NULL, NULL, '6351 At St.', 537, 'A', 'At Libero Consulting', 45926315, 1),
(13, 'Orson', 'Mckenzie', 'nec.ante.Maecenas@molestiedapibusligula.org', 'test', 'Ap #578-6249 Blandit St.', 55908474, '294 4476581', '294 462484', '', 'CLIENTE', 'luctus, ipsum leo elementum sem, vitae aliquam eros turpis non enim. Mauris quis turpis vitae purus gravida sagittis. Duis gravida. Praesent eu nulla at sem molestie sodales. Mauris blandit enim consequat purus. Maecenas libero est, congue a, aliquet vel, vulputate eu, odio. Phasellus at augue id ante dictum cursus. Nunc mauris elit, dictum eu, eleifend nec, malesuada ut, sem. Nulla interdum. Curabitur dictum. Phasellus in felis. Nulla tempor augue ac ipsum. Phasellus vitae mauris sit amet lorem semper auctor. Mauris vel turpis. Aliquam adipiscing lobortis risus.', NULL, NULL, NULL, 'P.O. Box 693, 9422 Semper Street', 846, 'B', 'Pretium Neque Morbi Institute', 94109277, 1),
(14, 'Patience', 'Trevino', 'vel.est.tempor@euarcuMorbi.org', 'test', 'Ap #266-1732 Magna. Ave', 65483635, '294 4063240', '294 486545', '', 'CLIENTE', 'Fusce aliquet magna a neque. Nullam ut nisi a odio semper cursus. Integer mollis. Integer tincidunt aliquam arcu. Aliquam ultrices iaculis odio. Nam interdum enim non nisi. Aenean eget metus. In nec', NULL, NULL, NULL, 'P.O. Box 868, 310 Quis Rd.', 596, 'B', 'Vel Venenatis Vel Institute', 96983351, 1),
(15, 'Buffy', 'Griffith', 'Proin.non.massa@lacinia.edu', 'test', '822-5243 Nonummy Avenue', 11059319, '294 4302757', '294 448789', '', 'CLIENTE', 'nonummy ac, feugiat non, lobortis quis, pede. Suspendisse dui. Fusce diam nunc, ullamcorper eu, euismod ac, fermentum vel, mauris. Integer sem elit, pharetra ut, pharetra sed, hendrerit a, arcu. Sed et libero. Proin mi. Aliquam gravida mauris ut mi. Duis risus odio, auctor vitae, aliquet nec, imperdiet nec, leo. Morbi neque tellus, imperdiet non, vestibulum', NULL, NULL, NULL, '912-9753 Aliquet Av.', 691, 'B', 'Nibh Aliquam Ornare Foundation', 64663826, 1),
(16, 'Dale', 'Williamson', 'Donec.nibh.Quisque@interdumNuncsollicitudin.com', 'test', 'P.O. Box 348, 6821 Accumsan Street', 70808962, '294 4684182', '294 442131', '', 'CLIENTE', 'habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aliquam fringilla cursus purus. Nullam scelerisque neque sed sem egestas blandit. Nam nulla magna, malesuada vel, convallis in, cursus et, eros. Proin ultrices. Duis volutpat nunc sit amet', NULL, NULL, NULL, 'P.O. Box 938, 5529 Sed St.', 520, 'B', 'Tellus Ltd', 29451615, 1),
(17, 'Meredith', 'Stuart', 'lectus.quis@velit.org', 'test', '2013 A Avenue', 18830448, '294 4834549', '294 424085', '', 'CLIENTE', 'volutpat. Nulla', NULL, NULL, NULL, 'P.O. Box 725, 4584 Scelerisque, Rd.', 135, 'B', 'Eu LLC', 94653548, 1),
(18, 'Nomlanga', 'Briggs', 'amet.consectetuer.adipiscing@tellus.org', 'test', '580-9624 Diam Av.', 35880081, '294 4565441', '294 436567', '294 436732', 'CLIENTE', 'Quisque purus', NULL, NULL, NULL, 'Ap #410-6042 Auctor. Rd.', 681, 'B', 'Lacus Pede Sagittis Corp.', 17633359, 1),
(19, 'John', 'Cobb', 'luctus.vulputate.nisi@a.org', 'test', '1296 Nulla Avenue', 68874958, '294 4197646', '294 449170', '', 'CLIENTE', 'ante. Maecenas mi felis, adipiscing fringilla, porttitor vulputate, posuere vulputate, lacus. Cras interdum. Nunc sollicitudin commodo ipsum. Suspendisse non leo. Vivamus nibh dolor, nonummy ac, feugiat non, lobortis quis, pede. Suspendisse dui. Fusce diam nunc, ullamcorper eu, euismod ac, fermentum vel, mauris. Integer sem elit, pharetra ut,', NULL, NULL, NULL, '827-6699 Et St.', 578, 'B', 'Nec LLC', 50519790, 1),
(20, 'Willow', 'Patton', 'pede@necimperdiet.net', 'test', 'P.O. Box 459, 5666 Nisi Av.', 27972757, '294 4439613', '294 486762', '', 'CLIENTE', 'eu, accumsan sed, facilisis vitae, orci. Phasellus dapibus quam quis diam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Fusce aliquet magna a neque. Nullam ut nisi a odio semper cursus. Integer mollis. Integer tincidunt aliquam arcu. Aliquam ultrices iaculis odio.', NULL, NULL, NULL, 'P.O. Box 437, 5917 Cursus Rd.', 501, 'B', 'Enim Mauris Quis Associates', 42257612, 1),
(21, 'Jorden', 'Briggs', 'at.velit@purusin.com', 'test', '6103 Sit St.', 20114476, '294 4964502', '294 403440', '', 'CLIENTE', 'sed dui. Fusce aliquam, enim nec tempus scelerisque, lorem ipsum sodales purus, in molestie tortor nibh sit amet orci. Ut sagittis lobortis mauris. Suspendisse aliquet molestie tellus. Aenean egestas hendrerit neque. In', NULL, NULL, NULL, '8581 Dui, Ave', 897, 'B', 'Ligula Aliquam Erat Institute', 46165122, 1),
(22, 'Maia', 'Hendricks', 'sem.vitae.aliquam@Aenean.co.uk', 'test', 'Ap #610-1139 Purus, Street', 86751812, '294 4715353', '294 493796', '', 'CLIENTE', 'Suspendisse commodo tincidunt nibh. Phasellus nulla. Integer vulputate, risus a ultricies adipiscing, enim mi tempor', NULL, NULL, NULL, '4756 Eget Av.', 764, 'B', 'Eu Accumsan Sed LLC', 2373589, 1),
(23, 'Xandra', 'Fisher', 'diam.vel@vulputateposuerevulputate.org', 'test', '8232 Enim, Road', 15109853, '294 4894550', '294 401027', '', 'CLIENTE', 'leo, in lobortis tellus justo sit amet nulla. Donec non justo. Proin non massa non ante bibendum ullamcorper. Duis cursus, diam at pretium aliquet, metus urna convallis erat, eget tincidunt dui augue eu tellus. Phasellus elit pede, malesuada vel, venenatis vel, faucibus id, libero. Donec consectetuer mauris id sapien. Cras dolor', NULL, NULL, NULL, '960-5369 Vitae Ave', 648, 'C', 'Neque Venenatis Lacus Corporation', 96359716, 1),
(24, 'Xander', 'Chase', 'tincidunt.pede@egestashendreritneque.edu', 'test', '111 Libero Av.', 37955161, '294 4393250', '294 458798', '', 'CLIENTE', 'magna. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Etiam laoreet, libero et tristique pellentesque, tellus sem mollis dui, in sodales elit erat vitae risus. Duis a mi fringilla mi lacinia mattis. Integer eu lacus. Quisque imperdiet, erat nonummy ultricies ornare, elit elit fermentum', NULL, NULL, NULL, 'Ap #896-3614 Parturient Ave', 966, 'C', 'Mauris Erat Eget Consulting', 86622141, 1),
(25, 'Mark', 'Gates', 'hendrerit.a.arcu@convallis.edu', 'test', '482-9179 Urna Road', 16809938, '294 4750764', '294 478802', '294 402703', 'CLIENTE', 'ac mattis velit justo nec ante. Maecenas mi felis, adipiscing fringilla, porttitor vulputate, posuere vulputate, lacus. Cras interdum. Nunc sollicitudin commodo ipsum. Suspendisse non leo. Vivamus nibh dolor, nonummy ac, feugiat non, lobortis quis, pede. Suspendisse dui. Fusce diam nunc, ullamcorper eu, euismod ac, fermentum vel, mauris. Integer sem elit, pharetra ut, pharetra sed, hendrerit a, arcu. Sed et libero. Proin mi. Aliquam gravida', NULL, NULL, NULL, '7963 Egestas Rd.', 845, 'C', 'Duis Ac Corporation', 55854292, 1),
(26, 'Travis', 'Houston', 'dui@velit.net', 'test', '874-2407 Ligula Ave', 59822333, '294 4540765', '294 461366', '', 'CLIENTE', 'lorem. Donec elementum, lorem ut aliquam iaculis, lacus pede sagittis augue, eu tempor erat neque non quam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aliquam fringilla cursus purus. Nullam scelerisque neque sed sem egestas blandit.', NULL, NULL, NULL, '576-3241 Quisque Av.', 739, 'C', 'Elit Curabitur Sed PC', 51190636, 1),
(27, 'Duncan', 'Montgomery', 'imperdiet.non@famesac.com', 'test', '220-4848 Elit. Avenue', 28324176, '294 4253381', '294 443104', '', 'CLIENTE', 'pede, malesuada vel, venenatis vel, faucibus id, libero. Donec consectetuer mauris id sapien. Cras dolor dolor, tempus non, lacinia at, iaculis quis, pede. Praesent eu dui. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Aenean eget magna. Suspendisse tristique neque venenatis lacus. Etiam bibendum fermentum metus. Aenean sed pede nec ante blandit viverra. Donec tempus, lorem fringilla ornare placerat, orci lacus vestibulum lorem, sit amet ultricies sem magna nec quam. Curabitur vel lectus. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec dignissim', NULL, NULL, NULL, '392-5771 Consectetuer Avenue', 678, 'C', 'Nunc Inc.', 38724591, 1),
(28, 'Ariana', 'Watson', 'lorem@consectetueradipiscing.net', 'test', '3712 Faucibus Av.', 51207502, '294 4262293', '294 461333', '', 'CLIENTE', 'convallis dolor. Quisque tincidunt pede ac urna. Ut tincidunt vehicula risus.', NULL, NULL, NULL, 'P.O. Box 386, 664 Porttitor St.', 627, 'C', 'Lobortis Nisi Ltd', 91704379, 1),
(29, 'Upton', 'Stanton', 'mollis.lectus.pede@ligula.org', 'test', '741-3498 Bibendum St.', 43761914, '294 4439901', '294 474882', '', 'CLIENTE', 'placerat eget, venenatis a, magna. Lorem ipsum', NULL, NULL, NULL, 'P.O. Box 940, 373 Vitae St.', 37, 'C', 'Aliquet Libero Consulting', 28850857, 1),
(30, 'Quintessa', 'Livingston', 'gravida.sagittis@consectetuermaurisid.net', 'test', 'Ap #213-2052 Turpis St.', 46112961, '294 4484583', '294 437139', '', 'CLIENTE', 'non, egestas a, dui. Cras pellentesque. Sed dictum. Proin eget odio. Aliquam vulputate ullamcorper magna. Sed eu eros. Nam consequat dolor vitae dolor. Donec', NULL, NULL, NULL, 'Ap #235-3208 Luctus Avenue', 419, 'C', 'Dui Nec Corporation', 47599166, 1),
(31, 'Hedwig', 'Rocha', 'euismod@magna.org', 'test', 'Ap #663-9940 Convallis Ave', 30817154, '294 4328785', '294 440708', '294 424905', 'CLIENTE', 'sed, sapien. Nunc pulvinar arcu et pede. Nunc sed orci lobortis augue scelerisque mollis. Phasellus libero mauris, aliquam', NULL, NULL, NULL, '1052 Tristique Rd.', 717, 'C', 'Ullamcorper Viverra Maecenas Inc.', 55460335, 1),
(32, 'Driscoll', 'Compton', 'mus.Proin@vehiculaetrutrum.com', 'test', '7895 Curae St.', 54539386, '294 4970563', '294 445200', '294 469014', 'CLIENTE', 'Suspendisse commodo tincidunt nibh. Phasellus nulla. Integer vulputate, risus a ultricies adipiscing, enim mi tempor lorem, eget mollis lectus pede et risus. Quisque libero lacus, varius et, euismod et, commodo at, libero. Morbi accumsan laoreet ipsum. Curabitur consequat, lectus sit amet luctus vulputate, nisi sem semper erat, in consectetuer ipsum nunc id enim. Curabitur massa.', NULL, NULL, NULL, 'P.O. Box 931, 1591 Vitae, Avenue', 408, 'C', 'Ac Tellus Associates', 88615857, 1),
(33, 'Yoko', 'Wagner', 'dui@Crasvulputate.net', 'test', 'Ap #199-2276 Sagittis St.', 22095167, '294 4093734', '294 402088', '', 'CLIENTE', 'augue malesuada malesuada. Integer id magna et ipsum cursus vestibulum. Mauris magna. Duis dignissim tempor arcu. Vestibulum ut eros non enim commodo hendrerit.', NULL, NULL, NULL, 'Ap #597-3420 Donec Rd.', 745, 'A', 'Pellentesque Sed Dictum LLP', 13080180, 1),
(34, 'Omar', 'Knox', 'egestas.Duis.ac@facilisiSedneque.co.uk', 'test', 'Ap #300-9953 Ligula Avenue', 42389658, '294 4672276', '294 497645', '', 'CLIENTE', 'vel,', NULL, NULL, NULL, '2417 Vel St.', 759, 'A', 'Felis Associates', 88454749, 1),
(35, 'Emery', 'Mccall', 'dolor.Quisque.tincidunt@nuncIn.net', 'test', '487-9989 Ut, Avenue', 84797824, '294 4120795', '294 472656', '294 431653', 'CLIENTE', 'pede blandit congue. In scelerisque scelerisque dui. Suspendisse ac metus vitae velit egestas lacinia. Sed congue, elit sed consequat auctor, nunc nulla vulputate dui, nec tempus mauris erat eget ipsum. Suspendisse sagittis. Nullam vitae diam. Proin dolor. Nulla semper tellus id nunc interdum feugiat. Sed nec metus facilisis lorem tristique aliquet. Phasellus fermentum convallis ligula. Donec luctus aliquet odio. Etiam ligula tortor, dictum eu, placerat eget, venenatis a, magna. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Etiam laoreet, libero', NULL, NULL, NULL, '760 Nullam Rd.', 9, 'A', 'Aliquet LLC', 19651569, 1),
(36, 'Zena', 'Lawson', 'eu@dictum.co.uk', 'test', 'P.O. Box 649, 3467 Scelerisque St.', 21050914, '294 4626446', '294 497983', '', 'CLIENTE', 'penatibus et magnis dis parturient montes, nascetur ridiculus mus. Aenean eget magna. Suspendisse tristique neque venenatis lacus. Etiam bibendum fermentum metus. Aenean sed pede nec ante blandit viverra. Donec tempus, lorem fringilla ornare placerat, orci lacus vestibulum lorem,', NULL, NULL, NULL, 'P.O. Box 732, 1756 Mattis. Street', 772, 'A', 'Scelerisque Mollis Phasellus LLP', 85551799, 1),
(37, 'Willa', 'Mccray', 'malesuada.fames@Duisdignissim.com', 'test', 'Ap #525-3652 Consequat, St.', 77821579, '294 4568741', '294 448110', '', 'CLIENTE', 'lacus. Mauris non dui nec urna suscipit nonummy. Fusce fermentum fermentum arcu. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae Phasellus ornare. Fusce mollis. Duis sit amet diam eu dolor egestas rhoncus. Proin nisl sem, consequat nec, mollis vitae, posuere at, velit. Cras lorem lorem, luctus ut, pellentesque eget, dictum placerat, augue. Sed molestie. Sed id risus quis diam luctus lobortis. Class aptent taciti', NULL, NULL, NULL, '222-1720 Vitae Ave', 595, 'A', 'Sed Eu Nibh Corp.', 4175081, 1),
(38, 'Leslie', 'Caldwell', 'a.enim@massanonante.co.uk', 'test', '954-9316 Consectetuer St.', 31335433, '294 4045036', '294 421122', '', 'CLIENTE', 'malesuada vel, venenatis vel, faucibus id, libero. Donec consectetuer mauris id sapien. Cras dolor dolor, tempus non, lacinia at, iaculis quis, pede. Praesent eu dui. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Aenean eget magna. Suspendisse tristique neque venenatis lacus. Etiam bibendum fermentum metus. Aenean sed pede nec ante blandit viverra. Donec tempus, lorem fringilla ornare placerat, orci lacus vestibulum lorem, sit amet', NULL, NULL, NULL, 'Ap #567-5028 Mattis Av.', 878, 'A', 'Malesuada Fringilla Est PC', 47768178, 1),
(39, 'John', 'Farrell', 'Sed.et.libero@cursus.net', 'test', '6601 Dapibus St.', 79961149, '294 4137258', '294 430720', '', 'CLIENTE', 'at, libero. Morbi accumsan laoreet ipsum. Curabitur consequat, lectus sit amet luctus vulputate, nisi sem semper erat, in consectetuer ipsum nunc id', NULL, NULL, NULL, 'P.O. Box 113, 1509 Dui. Avenue', 591, 'A', 'Natoque Consulting', 8522237, 1),
(40, 'Martin', 'Walton', 'nec.mollis.vitae@mifelisadipiscing.com', 'test', 'P.O. Box 649, 7970 Sagittis Street', 79322442, '294 4828671', '294 409734', '', 'CLIENTE', 'consequat purus. Maecenas libero est, congue a, aliquet vel, vulputate eu, odio. Phasellus at augue id ante dictum cursus. Nunc mauris elit, dictum eu, eleifend nec, malesuada ut, sem. Nulla interdum. Curabitur dictum. Phasellus in felis. Nulla tempor augue ac ipsum. Phasellus vitae mauris sit amet lorem semper auctor. Mauris vel turpis. Aliquam adipiscing lobortis risus. In mi pede, nonummy ut, molestie in,', NULL, NULL, NULL, '2104 Diam Rd.', 942, 'A', 'Molestie Sed Id Institute', 82550403, 1),
(41, 'Daphne', 'Shaw', 'dolor@sedestNunc.ca', 'test', 'Ap #324-3637 Senectus Av.', 31221607, '294 4369567', '294 414557', '', 'CLIENTE', 'sed consequat auctor, nunc nulla vulputate dui, nec tempus mauris erat eget ipsum. Suspendisse sagittis. Nullam vitae diam. Proin dolor. Nulla semper tellus', NULL, NULL, NULL, 'P.O. Box 370, 7113 Eu, Road', 36, 'A', 'Sit Amet Corp.', 8225462, 1),
(42, 'Dara', 'Ayala', 'pulvinar.arcu.et@convallisantelectus.edu', 'test', 'Ap #704-2856 Integer St.', 19055055, '294 4400150', '294 415872', '', 'CLIENTE', 'aliquam adipiscing lacus. Ut nec urna et arcu imperdiet ullamcorper. Duis at lacus. Quisque purus sapien, gravida non, sollicitudin a, malesuada id, erat. Etiam vestibulum massa rutrum magna. Cras convallis convallis dolor. Quisque tincidunt pede ac urna. Ut tincidunt vehicula risus. Nulla eget metus eu erat semper rutrum. Fusce dolor quam, elementum at, egestas a, scelerisque sed, sapien. Nunc pulvinar arcu et pede. Nunc sed orci lobortis augue scelerisque mollis. Phasellus libero mauris, aliquam eu,', NULL, NULL, NULL, '346-6855 In Avenue', 913, 'A', 'Magna LLC', 30903114, 1),
(43, 'Hanae', 'Valenzuela', 'id@infelisNulla.edu', 'test', 'Ap #487-5550 Etiam St.', 32667149, '294 4651592', '294 462348', '', 'CLIENTE', 'mauris eu elit. Nulla facilisi. Sed neque. Sed eget lacus. Mauris non dui nec urna suscipit nonummy. Fusce fermentum fermentum arcu. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae Phasellus ornare. Fusce mollis. Duis sit amet diam eu dolor egestas rhoncus. Proin nisl sem, consequat nec, mollis vitae, posuere at, velit. Cras lorem lorem, luctus ut, pellentesque eget,', NULL, NULL, NULL, 'Ap #823-6999 Ac, Rd.', 37, 'B', 'Facilisi Sed Corp.', 82260328, 1),
(44, 'Raphael', 'Santiago', 'id.libero@commodoauctor.ca', 'test', 'P.O. Box 425, 462 Consequat St.', 35952429, '294 4685914', '294 406812', '', 'CLIENTE', 'rutrum magna. Cras convallis convallis dolor. Quisque tincidunt pede ac urna. Ut tincidunt vehicula risus. Nulla eget metus eu erat semper', NULL, NULL, NULL, '1147 Et, St.', 948, 'B', 'Dictum Associates', 55914676, 1),
(45, 'Chester', 'Mcleod', 'tortor.Integer.aliquam@ipsum.ca', 'test', '100-322 Duis Av.', 54068545, '294 4153708', '294 400865', '294 405178', 'CLIENTE', 'Nunc commodo auctor velit. Aliquam nisl. Nulla eu neque pellentesque', NULL, NULL, NULL, 'P.O. Box 495, 674 Commodo Av.', 621, 'B', 'Et Rutrum Industries', 80137407, 1),
(46, 'Echo', 'Cobb', 'interdum.ligula.eu@enimCurabiturmassa.co.uk', 'test', '8316 Amet Ave', 86523753, '294 4258103', '294 409244', '', 'CLIENTE', 'Sed nulla ante, iaculis nec, eleifend non, dapibus rutrum, justo. Praesent luctus. Curabitur egestas nunc sed libero. Proin sed turpis nec mauris blandit mattis. Cras eget nisi dictum augue malesuada malesuada. Integer id magna et ipsum cursus vestibulum. Mauris magna. Duis dignissim tempor arcu. Vestibulum ut eros non enim commodo hendrerit. Donec porttitor tellus non magna. Nam ligula elit, pretium et, rutrum non, hendrerit id, ante. Nunc mauris sapien, cursus in,', NULL, NULL, NULL, 'P.O. Box 460, 1303 Vitae St.', 647, 'B', 'Sed Corp.', 81175974, 1),
(47, 'Phillip', 'Pate', 'sapien@faucibusorciluctus.org', 'test', '1861 Ac Ave', 71325170, '294 4601835', '294 483237', '', 'CLIENTE', 'rutrum urna, nec luctus felis purus ac tellus. Suspendisse sed dolor. Fusce mi lorem, vehicula et, rutrum eu, ultrices sit amet, risus. Donec nibh enim, gravida sit amet, dapibus id, blandit at, nisi. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Proin vel nisl. Quisque fringilla euismod enim. Etiam gravida molestie', NULL, NULL, NULL, 'Ap #980-6701 Mattis Rd.', 221, 'B', 'Arcu Company', 24149900, 1),
(48, 'Cooper', 'Moody', 'Proin@Aeneanegetmagna.com', 'test', '175-1903 Maecenas St.', 38561010, '294 4644148', '294 471086', '', 'CLIENTE', 'Nulla semper tellus id nunc interdum feugiat. Sed nec metus facilisis lorem tristique aliquet. Phasellus fermentum convallis ligula. Donec luctus aliquet odio. Etiam ligula tortor, dictum eu, placerat eget, venenatis a, magna. Lorem ipsum dolor sit amet, consectetuer adipiscing', NULL, NULL, NULL, 'P.O. Box 496, 9547 Mollis St.', 927, 'B', 'Ac Urna Ut LLC', 21140094, 1),
(49, 'Tanisha', 'Daugherty', 'Nulla.dignissim.Maecenas@Suspendisseacmetus.org', 'test', '6195 Pede, St.', 45710793, '294 4574451', '294 496930', '', 'CLIENTE', 'amet massa. Quisque porttitor eros nec tellus. Nunc lectus pede, ultrices a, auctor non, feugiat nec, diam. Duis mi enim, condimentum eget, volutpat ornare, facilisis eget, ipsum. Donec sollicitudin adipiscing ligula. Aenean gravida nunc sed pede. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Proin vel', NULL, NULL, NULL, 'P.O. Box 860, 1123 Faucibus Rd.', 933, 'B', 'Elit Corporation', 66188853, 1),
(50, 'Barrett', 'Frost', 'ullamcorper.Duis.cursus@nequepellentesquemassa.org', 'test', 'Ap #104-6900 Diam Av.', 25178972, '294 4408989', '294 484162', '', 'CLIENTE', 'fringilla est. Mauris eu turpis. Nulla aliquet. Proin velit. Sed malesuada augue ut lacus. Nulla tincidunt, neque vitae semper egestas, urna justo faucibus lectus, a sollicitudin orci sem eget massa. Suspendisse eleifend.', NULL, NULL, NULL, '242-697 Lobortis St.', 542, 'B', 'Lorem Donec Elementum Consulting', 98441738, 1),
(51, 'Nora', 'Price', 'varius@Fuscefeugiat.net', 'test', '1494 Pede St.', 66308299, '294 4182412', '294 453948', '', 'CLIENTE', 'rutrum non, hendrerit id, ante. Nunc mauris sapien, cursus in, hendrerit consectetuer, cursus et, magna. Praesent interdum ligula eu enim. Etiam imperdiet dictum magna. Ut tincidunt orci quis lectus. Nullam suscipit, est ac facilisis facilisis, magna tellus faucibus', NULL, NULL, NULL, 'P.O. Box 617, 5697 Diam. Road', 631, 'B', 'Interdum Curabitur Dictum Ltd', 65941152, 1),
(52, 'Aretha', 'Boyer', 'sit.amet@massalobortisultrices.com', 'test', '847-8922 Lacus. St.', 54223300, '294 4024270', '294 436962', '', 'CLIENTE', 'vel nisl. Quisque fringilla euismod enim. Etiam gravida molestie arcu. Sed eu nibh vulputate mauris sagittis placerat.', NULL, NULL, NULL, 'Ap #112-2783 Semper St.', 658, 'B', 'Orci Lobortis Industries', 18147512, 1),
(53, 'Lara', 'Walters', 'amet@Sedid.co.uk', 'test', '5094 Quam. Avenue', 27673255, '294 4806527', '294 436689', '', 'CLIENTE', 'mollis. Duis sit amet diam eu dolor egestas rhoncus. Proin nisl sem, consequat nec, mollis vitae, posuere at, velit. Cras lorem lorem, luctus ut, pellentesque eget, dictum placerat, augue. Sed molestie. Sed id risus quis diam luctus lobortis. Class aptent taciti sociosqu', NULL, NULL, NULL, 'Ap #380-1104 Lorem Street', 807, 'C', 'Vulputate Corporation', 13835299, 1),
(54, 'Jacqueline', 'Wade', 'ante.dictum.cursus@afacilisis.ca', 'test', 'P.O. Box 860, 4832 Imperdiet Av.', 72332643, '294 4078031', '294 493553', '', 'CLIENTE', 'consequat purus. Maecenas libero est, congue a, aliquet vel, vulputate eu, odio. Phasellus at augue id ante dictum cursus. Nunc mauris elit, dictum eu, eleifend nec, malesuada ut, sem. Nulla interdum. Curabitur dictum. Phasellus in felis. Nulla tempor augue ac ipsum. Phasellus vitae mauris sit amet lorem semper auctor. Mauris vel turpis. Aliquam adipiscing lobortis risus. In mi pede, nonummy ut, molestie in, tempus eu, ligula. Aenean euismod mauris eu elit. Nulla facilisi. Sed neque. Sed eget lacus. Mauris non dui nec urna suscipit nonummy. Fusce fermentum fermentum arcu. Vestibulum ante ipsum primis in faucibus orci', NULL, NULL, NULL, 'P.O. Box 612, 1674 Est, Av.', 709, 'C', 'Commodo Tincidunt Nibh Company', 82670286, 1),
(55, 'Heidi', 'Mccarty', 'dictum.eu.placerat@Nullatempor.org', 'test', '655-3227 Penatibus Rd.', 64750306, '294 4579159', '294 482869', '', 'CLIENTE', 'convallis in, cursus et, eros. Proin ultrices. Duis volutpat nunc sit amet metus. Aliquam erat volutpat. Nulla facilisis. Suspendisse commodo tincidunt nibh. Phasellus nulla. Integer vulputate, risus a ultricies adipiscing, enim mi tempor lorem, eget mollis lectus pede et risus. Quisque libero lacus, varius et, euismod et, commodo at, libero. Morbi accumsan laoreet ipsum. Curabitur consequat, lectus sit amet luctus vulputate, nisi sem semper erat, in consectetuer ipsum nunc id enim. Curabitur massa. Vestibulum accumsan neque et nunc. Quisque ornare tortor at', NULL, NULL, NULL, 'P.O. Box 804, 8706 Bibendum St.', 983, 'C', 'Lorem Ipsum Dolor Ltd', 94325715, 1),
(56, 'Blake', 'Gardner', 'Pellentesque@condimentum.ca', 'test', '236-6272 Mauris, Road', 87800911, '294 4919716', '294 415124', '', 'CLIENTE', 'consequat purus. Maecenas libero est, congue a, aliquet vel, vulputate eu, odio. Phasellus at augue id ante dictum cursus. Nunc mauris elit, dictum eu, eleifend nec, malesuada ut, sem. Nulla interdum. Curabitur dictum. Phasellus in felis. Nulla tempor augue ac ipsum. Phasellus vitae mauris sit amet lorem semper auctor. Mauris vel turpis. Aliquam adipiscing lobortis risus. In mi pede,', NULL, NULL, NULL, 'P.O. Box 215, 680 Pellentesque. St.', 437, 'C', 'Gravida Molestie Arcu Foundation', 23875283, 1),
(57, 'Caesar', 'Mathews', 'tristique.senectus.et@lacusvariuset.net', 'test', 'Ap #889-8535 Nulla St.', 41428523, '294 4239414', '294 498081', '', 'CLIENTE', 'tempus risus. Donec egestas. Duis ac arcu. Nunc mauris. Morbi non sapien molestie orci tincidunt adipiscing. Mauris molestie pharetra nibh. Aliquam ornare,', NULL, NULL, NULL, '8923 Purus Ave', 650, 'C', 'Aliquam Tincidunt Nunc Foundation', 32681889, 1),
(58, 'Flynn', 'Tillman', 'enim.gravida@Etiamimperdiet.co.uk', 'test', 'Ap #638-428 Purus. Street', 19938019, '294 4834897', '294 477228', '', 'CLIENTE', 'varius. Nam porttitor scelerisque neque. Nullam nisl. Maecenas malesuada fringilla est. Mauris eu turpis. Nulla aliquet. Proin velit. Sed malesuada augue ut lacus. Nulla tincidunt, neque vitae semper egestas, urna justo faucibus lectus, a sollicitudin orci sem eget massa. Suspendisse eleifend. Cras sed leo. Cras vehicula aliquet libero. Integer in magna. Phasellus dolor elit, pellentesque a, facilisis non, bibendum sed, est. Nunc laoreet lectus quis', NULL, NULL, NULL, '5261 Phasellus Rd.', 845, 'C', 'Vestibulum Nec Euismod Incorporated', 24858209, 1),
(59, 'Zenia', 'Fitzgerald', 'sem.Pellentesque@Craseget.ca', 'test', 'Ap #997-1470 Dolor. Avenue', 32440584, '294 4864398', '294 452079', '', 'CLIENTE', 'Duis cursus, diam at pretium aliquet, metus urna convallis erat, eget tincidunt dui augue eu tellus. Phasellus elit pede, malesuada vel, venenatis vel, faucibus id, libero. Donec consectetuer mauris id sapien. Cras dolor dolor, tempus non, lacinia at, iaculis quis, pede. Praesent eu dui. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Aenean eget magna. Suspendisse tristique neque venenatis lacus. Etiam bibendum fermentum metus. Aenean sed pede', NULL, NULL, NULL, '3920 Bibendum Avenue', 537, 'C', 'Ac Inc.', 8737590, 1),
(60, 'Melissa', 'Mcclure', 'mollis.non.cursus@lacusQuisque.co.uk', 'test', 'Ap #145-7791 Tincidunt Rd.', 21694260, '294 4454025', '294 488241', '', 'CLIENTE', 'interdum. Nunc sollicitudin commodo ipsum. Suspendisse non leo. Vivamus nibh dolor, nonummy ac, feugiat non, lobortis quis, pede. Suspendisse dui. Fusce diam nunc, ullamcorper eu, euismod ac, fermentum vel, mauris. Integer sem elit, pharetra', NULL, NULL, NULL, '250-4783 Eu St.', 585, 'C', 'Erat Vivamus Nisi Inc.', 32341625, 1),
(61, 'Lucian', 'Sargent', 'Quisque@mollis.net', 'test', 'P.O. Box 277, 2614 Duis Road', 23884165, '294 4442550', '294 484548', '', 'CLIENTE', 'non massa non ante bibendum ullamcorper. Duis cursus, diam at pretium aliquet, metus urna convallis erat, eget tincidunt dui augue eu tellus. Phasellus elit pede, malesuada vel, venenatis vel,', NULL, NULL, NULL, 'Ap #867-4402 Tristique Av.', 419, 'C', 'Sodales Limited', 43319877, 1),
(62, 'Whilemina', 'Velasquez', 'ligula.elit@tinciduntpedeac.net', 'test', 'Ap #344-1407 Semper Street', 38166601, '294 4247146', '294 437671', '', 'CLIENTE', 'adipiscing elit. Etiam laoreet, libero et', NULL, NULL, NULL, '213-431 Sociis Ave', 361, 'C', 'Sed Id Risus Consulting', 10073626, 1),
(63, 'Colby', 'Figueroa', 'dapibus@utquam.edu', 'test', '513-3959 Amet, St.', 52717497, '294 4206316', '294 494276', '', 'CLIENTE', 'at, iaculis quis, pede. Praesent eu dui. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Aenean eget magna. Suspendisse tristique neque venenatis lacus. Etiam bibendum fermentum metus.', NULL, NULL, NULL, 'P.O. Box 366, 8972 Purus, Ave', 103, 'A', 'Vitae Erat Vel Corp.', 88443447, 1),
(64, 'Odette', 'Mcgowan', 'Praesent.interdum.ligula@ante.com', 'test', 'P.O. Box 162, 8535 Suspendisse Rd.', 72538317, '294 4142226', '294 450409', '', 'CLIENTE', 'feugiat nec, diam. Duis mi enim, condimentum eget, volutpat ornare, facilisis eget, ipsum. Donec sollicitudin adipiscing ligula. Aenean gravida nunc sed pede. Cum sociis natoque penatibus', NULL, NULL, NULL, '644-8894 Curae St.', 188, 'A', 'Fringilla Consulting', 95938918, 1),
(65, 'Sean', 'Watson', 'id.risus.quis@urnaNullamlobortis.edu', 'test', '9104 Urna Av.', 20510858, '294 4182184', '294 417957', '294 434702', 'CLIENTE', 'Ut tincidunt vehicula risus. Nulla eget metus eu erat semper rutrum. Fusce dolor quam, elementum at, egestas a, scelerisque sed, sapien. Nunc pulvinar arcu et pede. Nunc sed orci lobortis augue scelerisque mollis. Phasellus libero mauris, aliquam eu, accumsan sed, facilisis vitae, orci. Phasellus dapibus quam quis diam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Fusce aliquet magna a neque. Nullam ut nisi a odio semper cursus. Integer mollis. Integer tincidunt aliquam arcu.', NULL, NULL, NULL, 'P.O. Box 477, 7747 Aliquam Rd.', 754, 'A', 'Nunc Quis Ltd', 56338070, 1),
(66, 'Pamela', 'Hunter', 'aliquam.adipiscing.lacus@aliquetlobortis.edu', 'test', '519-5749 Luctus. Av.', 20740139, '294 4078322', '294 440193', '', 'CLIENTE', 'et magnis dis parturient montes, nascetur ridiculus mus. Proin vel arcu eu odio tristique pharetra. Quisque ac libero nec ligula consectetuer rhoncus. Nullam velit dui, semper et, lacinia vitae, sodales at, velit. Pellentesque ultricies dignissim lacus. Aliquam rutrum lorem ac risus. Morbi metus. Vivamus euismod urna. Nullam lobortis quam a felis ullamcorper viverra. Maecenas iaculis aliquet diam. Sed diam lorem, auctor quis, tristique ac, eleifend vitae, erat. Vivamus nisi. Mauris nulla. Integer', NULL, NULL, NULL, 'P.O. Box 568, 4335 A, Avenue', 605, 'A', 'Placerat Ltd', 76249661, 1),
(67, 'Xanthus', 'Scott', 'nulla@convallisantelectus.com', 'test', '822-8407 Nulla Rd.', 81516868, '294 4376092', '294 470779', '', 'CLIENTE', 'rhoncus. Nullam velit dui, semper et, lacinia vitae, sodales at, velit. Pellentesque ultricies dignissim lacus. Aliquam rutrum lorem ac risus. Morbi metus. Vivamus euismod urna. Nullam lobortis quam a felis ullamcorper viverra. Maecenas iaculis aliquet diam. Sed diam lorem, auctor quis, tristique ac, eleifend vitae, erat. Vivamus nisi. Mauris nulla. Integer urna. Vivamus molestie dapibus ligula. Aliquam erat volutpat. Nulla dignissim. Maecenas ornare egestas ligula. Nullam feugiat placerat velit. Quisque varius. Nam porttitor scelerisque neque. Nullam nisl. Maecenas malesuada fringilla est. Mauris eu turpis. Nulla aliquet. Proin velit. Sed malesuada augue', NULL, NULL, NULL, '5880 Augue St.', 156, 'A', 'Pharetra Ut Pharetra Corporation', 89537162, 1),
(68, 'Tanya', 'Sharp', 'diam.Duis@Duisa.com', 'test', '347-7248 Congue Av.', 28808076, '294 4771682', '294 445459', '', 'CLIENTE', 'Praesent luctus. Curabitur egestas nunc sed libero. Proin sed turpis nec mauris blandit mattis. Cras eget nisi dictum augue malesuada malesuada. Integer id magna et ipsum cursus vestibulum. Mauris magna. Duis dignissim tempor arcu. Vestibulum ut eros non enim commodo hendrerit. Donec porttitor tellus non magna. Nam ligula elit,', NULL, NULL, NULL, 'P.O. Box 377, 6885 Fermentum Ave', 283, 'A', 'Felis Industries', 54811205, 1),
(69, 'May', 'Cabrera', 'vulputate@Crasvulputatevelit.com', 'test', '3257 Eget, Street', 16452952, '294 4410611', '294 489423', '', 'CLIENTE', 'natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec dignissim magna a tortor. Nunc commodo auctor velit. Aliquam nisl. Nulla eu neque pellentesque massa lobortis ultrices. Vivamus rhoncus. Donec est. Nunc ullamcorper, velit in aliquet lobortis, nisi nibh lacinia orci, consectetuer euismod est arcu ac orci.', NULL, NULL, NULL, '6101 Fusce Avenue', 680, 'A', 'Aenean Euismod Mauris Ltd', 74507527, 1),
(70, 'Hermione', 'Brock', 'nunc.est.mollis@convallis.net', 'test', 'P.O. Box 247, 2129 Aliquet Road', 85079810, '294 4916973', '294 471512', '', 'CLIENTE', 'sit amet, dapibus id, blandit at, nisi. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Proin vel nisl. Quisque fringilla euismod enim. Etiam gravida molestie arcu. Sed eu nibh vulputate mauris sagittis placerat. Cras dictum ultricies ligula. Nullam enim. Sed nulla ante, iaculis nec, eleifend non, dapibus rutrum, justo. Praesent luctus. Curabitur egestas nunc sed libero. Proin sed turpis nec mauris blandit mattis. Cras eget nisi dictum augue malesuada malesuada. Integer id magna et ipsum cursus', NULL, NULL, NULL, 'P.O. Box 178, 2297 Sem St.', 63, 'A', 'Quis Massa Foundation', 29025330, 1),
(71, 'Alana', 'Bradshaw', 'Donec@iaculisaliquet.net', 'test', '597 Lobortis St.', 54274443, '294 4172020', '294 454384', '', 'CLIENTE', 'eu nulla at sem molestie sodales. Mauris blandit enim consequat purus. Maecenas libero est, congue a, aliquet vel, vulputate eu, odio. Phasellus at augue id ante dictum cursus. Nunc mauris elit, dictum eu, eleifend nec, malesuada ut, sem. Nulla interdum. Curabitur dictum. Phasellus in felis.', NULL, NULL, NULL, '6921 Mauris St.', 996, 'A', 'Orci Sem Institute', 40665444, 1),
(72, 'Tatiana', 'Gibson', 'Duis.a.mi@libero.com', 'test', 'P.O. Box 175, 4474 Vulputate, Avenue', 66702204, '294 4597908', '294 494859', '', 'CLIENTE', 'arcu imperdiet ullamcorper. Duis at lacus. Quisque purus sapien, gravida non, sollicitudin a, malesuada id, erat. Etiam vestibulum massa rutrum magna. Cras convallis convallis dolor. Quisque tincidunt pede ac urna. Ut tincidunt vehicula risus. Nulla eget metus eu erat semper rutrum. Fusce dolor quam, elementum at, egestas a, scelerisque sed, sapien. Nunc pulvinar arcu et pede. Nunc sed orci lobortis augue scelerisque', NULL, NULL, NULL, '8902 Fringilla Ave', 229, 'A', 'Nisi Nibh Lacinia Industries', 76572152, 1),
(73, 'Anthony', 'Gill', 'ut.pharetra.sed@velturpis.com', 'test', '414-6576 Justo Rd.', 37339408, '294 4028250', '294 408318', '294 409443', 'CLIENTE', 'rhoncus id, mollis nec, cursus a, enim. Suspendisse aliquet, sem ut cursus luctus, ipsum leo elementum sem, vitae aliquam eros turpis non enim. Mauris quis turpis vitae purus gravida sagittis. Duis gravida. Praesent eu nulla at sem molestie sodales. Mauris blandit enim', NULL, NULL, NULL, '8668 Nam Street', 748, 'B', 'Diam At Pretium Corp.', 12590647, 1),
(74, 'Madaline', 'Shepherd', 'eu@elit.com', 'test', 'Ap #846-1355 Pellentesque Avenue', 72609294, '294 4483268', '294 475852', '', 'CLIENTE', 'Vivamus nisi. Mauris nulla. Integer urna. Vivamus molestie dapibus ligula. Aliquam erat volutpat. Nulla dignissim. Maecenas ornare egestas ligula. Nullam feugiat placerat velit. Quisque varius. Nam porttitor scelerisque neque. Nullam nisl. Maecenas malesuada fringilla est. Mauris eu turpis.', NULL, NULL, NULL, '536-3898 Diam St.', 327, 'B', 'Libero Donec Consectetuer Industries', 62937192, 1),
(75, 'Britanney', 'Rose', 'sodales.at.velit@diamdictumsapien.edu', 'test', 'P.O. Box 484, 9803 Sed Rd.', 61844180, '294 4916840', '294 455229', '', 'CLIENTE', 'elit, pellentesque a, facilisis non, bibendum sed, est. Nunc laoreet lectus quis', NULL, NULL, NULL, 'Ap #544-2117 Elit. Av.', 396, 'B', 'Et LLP', 60685209, 1),
(76, 'Karina', 'Hyde', 'risus.Donec@convallis.com', 'test', '210-5493 Diam St.', 38299669, '294 4226496', '294 446617', '', 'CLIENTE', 'purus. Duis elementum, dui quis accumsan convallis, ante lectus convallis est,', NULL, NULL, NULL, '933-5684 Mauris Avenue', 634, 'B', 'Accumsan Ltd', 73274803, 1),
(77, 'Justine', 'Knapp', 'tincidunt@sapienAeneanmassa.net', 'test', 'Ap #556-5668 Mauris. Ave', 44450669, '294 4669312', '294 419603', '', 'CLIENTE', 'Suspendisse eleifend. Cras sed leo. Cras', NULL, NULL, NULL, 'Ap #282-5115 Ac Av.', 336, 'B', 'Curabitur Consulting', 13603251, 1),
(78, 'Ferdinand', 'Shannon', 'Nunc@est.com', 'test', 'Ap #680-5662 Sapien, Ave', 46054165, '294 4062195', '294 425860', '', 'CLIENTE', 'Quisque ornare tortor at risus. Nunc ac sem ut dolor dapibus gravida. Aliquam tincidunt, nunc ac mattis ornare, lectus ante dictum mi, ac mattis velit justo', NULL, NULL, NULL, '472-1326 Aliquet, St.', 932, 'B', 'Suspendisse Sed Corp.', 54481271, 1),
(79, 'Laura', 'Murray', 'mi@mipede.org', 'test', '1454 A Rd.', 11265688, '294 4826245', '294 482369', '294 490731', 'CLIENTE', 'et, rutrum eu, ultrices', NULL, NULL, NULL, '180-1149 Cursus. St.', 247, 'B', 'Dui LLP', 9951856, 1),
(80, 'Frances', 'Vincent', 'purus.sapien.gravida@antedictumcursus.org', 'test', 'P.O. Box 813, 2484 Aliquet Rd.', 23696170, '294 4426749', '294 406260', '', 'CLIENTE', 'sem magna nec quam. Curabitur vel lectus. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec dignissim magna a tortor. Nunc commodo auctor velit. Aliquam nisl. Nulla eu neque pellentesque massa lobortis ultrices. Vivamus rhoncus. Donec est. Nunc ullamcorper, velit in aliquet lobortis, nisi nibh lacinia orci, consectetuer', NULL, NULL, NULL, '673-2576 Felis Road', 169, 'B', 'Libero Et Tristique Corp.', 18903697, 1),
(81, 'Eric', 'Roberts', 'Suspendisse.aliquet@rutrumlorem.edu', 'test', 'Ap #920-9666 In, Avenue', 45932202, '294 4839582', '294 436366', '', 'CLIENTE', 'Morbi sit amet massa. Quisque porttitor eros nec tellus. Nunc lectus pede, ultrices a, auctor non, feugiat nec, diam. Duis mi enim, condimentum eget, volutpat ornare, facilisis eget, ipsum. Donec sollicitudin adipiscing ligula. Aenean gravida nunc sed pede. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Proin vel arcu eu odio tristique pharetra. Quisque ac libero nec ligula consectetuer rhoncus. Nullam velit dui, semper et, lacinia vitae, sodales at, velit. Pellentesque ultricies dignissim lacus. Aliquam rutrum lorem ac risus. Morbi metus. Vivamus euismod urna. Nullam lobortis quam a', NULL, NULL, NULL, '540-852 Non, Street', 626, 'B', 'Enim Nunc LLP', 99104492, 1),
(82, 'Autumn', 'Keith', 'quis.tristique.ac@consectetuereuismodest.net', 'test', '204-9072 Mus. St.', 11444648, '294 4568777', '294 405003', '', 'CLIENTE', 'adipiscing lacus. Ut nec urna et arcu', NULL, NULL, NULL, '296-9225 Mauris Rd.', 568, 'B', 'Sit Amet Metus Institute', 78828054, 1),
(83, 'Yetta', 'Gonzales', 'Nunc.mauris@ipsum.com', 'test', '6853 Ut Street', 44883709, '294 4896558', '294 447321', '294 400872', 'CLIENTE', 'ornare, lectus ante dictum mi, ac mattis velit justo nec ante. Maecenas mi felis, adipiscing fringilla, porttitor vulputate, posuere vulputate, lacus. Cras interdum. Nunc sollicitudin commodo ipsum. Suspendisse non leo. Vivamus nibh dolor, nonummy ac, feugiat non, lobortis quis, pede. Suspendisse dui. Fusce diam nunc, ullamcorper eu, euismod ac, fermentum vel, mauris. Integer sem elit, pharetra ut, pharetra sed, hendrerit a, arcu. Sed et libero. Proin mi. Aliquam gravida mauris ut mi. Duis risus odio, auctor vitae, aliquet nec,', NULL, NULL, NULL, 'P.O. Box 577, 7194 Ipsum St.', 747, 'C', 'Mollis Non Cursus Institute', 32702305, 1),
(84, 'Kalia', 'Donovan', 'lorem.sit@antedictummi.edu', 'test', 'P.O. Box 536, 2629 Hendrerit Av.', 55434032, '294 4096527', '294 407495', '', 'CLIENTE', 'sem elit, pharetra ut, pharetra sed, hendrerit a, arcu. Sed et libero. Proin mi. Aliquam gravida mauris ut mi. Duis risus odio, auctor vitae, aliquet nec, imperdiet nec, leo. Morbi neque tellus, imperdiet non, vestibulum nec, euismod in, dolor. Fusce feugiat. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aliquam auctor, velit eget laoreet posuere, enim nisl elementum purus, accumsan interdum libero', NULL, NULL, NULL, 'Ap #752-2422 Lorem Avenue', 502, 'C', 'A Facilisis Incorporated', 15557954, 1),
(85, 'Dale', 'Carpenter', 'convallis.in.cursus@auctorquistristique.com', 'test', 'P.O. Box 426, 7103 Orci, Street', 20567234, '294 4782356', '294 452258', '', 'CLIENTE', 'non massa non ante bibendum ullamcorper. Duis cursus, diam at pretium aliquet, metus urna convallis erat, eget tincidunt dui augue eu tellus. Phasellus elit pede, malesuada vel, venenatis vel, faucibus id, libero. Donec consectetuer mauris id sapien. Cras dolor dolor, tempus non, lacinia at, iaculis quis, pede. Praesent eu dui.', NULL, NULL, NULL, '502-5580 Orci. St.', 97, 'C', 'Sem Molestie LLC', 40900297, 1),
(86, 'Demetrius', 'Logan', 'ornare.Fusce@imperdiet.org', 'test', '599-2472 Lorem, Rd.', 14540954, '294 4021658', '294 441266', '', 'CLIENTE', 'et netus et malesuada fames ac turpis egestas. Fusce aliquet magna a neque. Nullam ut nisi a odio semper cursus. Integer mollis. Integer tincidunt aliquam arcu. Aliquam ultrices iaculis odio. Nam interdum enim non nisi. Aenean eget metus. In nec orci. Donec nibh. Quisque nonummy ipsum non arcu. Vivamus sit amet risus. Donec egestas. Aliquam nec enim. Nunc ut erat. Sed nunc est, mollis non, cursus non, egestas a, dui. Cras pellentesque. Sed', NULL, NULL, NULL, '6599 Aenean Ave', 94, 'C', 'Ipsum Primis Company', 74049112, 1),
(87, 'Jeanette', 'Martinez', 'quam.Pellentesque.habitant@et.net', 'test', 'P.O. Box 248, 434 Metus. Ave', 40679021, '294 4135527', '294 469270', '294 493504', 'CLIENTE', 'Sed eu eros. Nam consequat dolor vitae dolor. Donec fringilla. Donec feugiat metus sit amet ante. Vivamus non lorem vitae odio sagittis semper. Nam tempor diam dictum sapien. Aenean massa. Integer vitae nibh. Donec est mauris, rhoncus id, mollis nec, cursus a, enim. Suspendisse aliquet, sem ut cursus luctus, ipsum leo elementum sem, vitae aliquam eros', NULL, NULL, NULL, 'Ap #249-6517 Donec St.', 753, 'C', 'Nulla Integer Limited', 78295556, 1),
(88, 'Rebecca', 'Horton', 'torquent@vitaemaurissit.com', 'test', 'Ap #607-555 Sapien, St.', 72760907, '294 4273585', '294 416212', '294 403866', 'CLIENTE', 'aliquet odio. Etiam ligula tortor, dictum eu, placerat eget, venenatis a, magna. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Etiam laoreet, libero et tristique pellentesque, tellus sem mollis dui, in sodales elit erat vitae risus. Duis a mi fringilla mi', NULL, NULL, NULL, '2734 Sagittis. Avenue', 667, 'C', 'Nonummy Ipsum Corporation', 55376483, 1),
(89, 'Kellie', 'Colon', 'In.condimentum.Donec@Duis.edu', 'test', 'P.O. Box 890, 6654 Ornare. Avenue', 41209881, '294 4620532', '294 473880', '', 'CLIENTE', 'odio,', NULL, NULL, NULL, 'Ap #178-1700 Sed Street', 433, 'C', 'Tincidunt Congue Turpis Incorporated', 93474598, 1),
(90, 'Rhona', 'Hogan', 'odio.Nam@dolor.com', 'test', '603-6817 Sed Ave', 43662880, '294 4542230', '294 435028', '', 'CLIENTE', 'cursus a, enim. Suspendisse aliquet, sem ut cursus luctus, ipsum leo elementum sem, vitae aliquam eros turpis non enim. Mauris quis turpis vitae purus gravida sagittis. Duis gravida. Praesent eu nulla at sem molestie sodales. Mauris blandit enim consequat purus. Maecenas libero est, congue a, aliquet vel, vulputate eu, odio. Phasellus at augue id ante dictum cursus. Nunc mauris elit, dictum eu, eleifend nec, malesuada ut, sem. Nulla interdum. Curabitur dictum. Phasellus in felis. Nulla tempor augue ac ipsum. Phasellus vitae mauris', NULL, NULL, NULL, 'P.O. Box 716, 8180 Nibh. St.', 302, 'C', 'Gravida Aliquam Industries', 7284536, 1),
(91, 'Kathleen', 'Cox', 'tellus.sem.mollis@atarcu.com', 'test', 'Ap #575-7465 Vitae, Street', 46001669, '294 4548369', '294 449180', '', 'CLIENTE', 'magna sed dui. Fusce aliquam, enim nec tempus scelerisque, lorem ipsum sodales purus, in molestie tortor nibh sit amet orci. Ut sagittis lobortis mauris. Suspendisse aliquet molestie tellus. Aenean egestas hendrerit neque. In ornare sagittis felis. Donec tempor, est ac mattis semper, dui lectus rutrum urna, nec luctus felis purus ac tellus. Suspendisse sed dolor. Fusce mi lorem, vehicula', NULL, NULL, NULL, '9844 A, Av.', 284, 'C', 'Mollis Lectus Inc.', 71773319, 1),
(92, 'Judah', 'Stewart', 'mattis.ornare.lectus@loremsitamet.co.uk', 'test', 'P.O. Box 143, 182 Urna. St.', 17810511, '294 4603745', '294 491717', '', 'CLIENTE', 'lectus. Nullam suscipit, est ac facilisis facilisis, magna tellus faucibus leo, in lobortis tellus justo sit amet nulla. Donec non justo. Proin non massa non ante bibendum ullamcorper. Duis cursus, diam at pretium aliquet, metus urna convallis erat, eget tincidunt dui augue eu tellus.', NULL, NULL, NULL, 'Ap #153-5872 Etiam Street', 367, 'C', 'Et Euismod Industries', 35532960, 1);
INSERT INTO `usuarios` (`usuario_id`, `nombre`, `apellido`, `email`, `password`, `direccion`, `dni`, `telefono_celular`, `telefono_fijo`, `telefono_alt`, `rol`, `comentarios`, `empleado_funcion`, `empleado_temporal`, `empleado_activo`, `cliente_direccion_cobro`, `cliente_sistema_secundario_id`, `cliente_factura`, `cliente_razon_social`, `cliente_cuit`, `tipos_cliente_tipo_cliente_id`) VALUES
(93, 'Maris', 'Waters', 'convallis@Fusce.org', 'test', 'Ap #551-7194 Nulla Av.', 34437061, '294 4572162', '294 412535', '', 'CLIENTE', 'Sed eu eros. Nam consequat dolor vitae dolor. Donec fringilla. Donec feugiat metus sit amet ante. Vivamus non lorem vitae odio sagittis semper. Nam tempor diam dictum sapien. Aenean massa. Integer vitae nibh. Donec est mauris, rhoncus id, mollis nec, cursus a, enim. Suspendisse aliquet, sem ut cursus luctus, ipsum leo elementum sem, vitae aliquam eros turpis non enim. Mauris quis turpis vitae purus gravida sagittis. Duis gravida. Praesent eu nulla at sem molestie sodales. Mauris blandit enim consequat purus. Maecenas libero est, congue', NULL, NULL, NULL, '550-1866 Fermentum Av.', 616, 'A', 'Nec Consulting', 86580875, 1),
(94, 'Herrod', 'Owen', 'libero.Morbi@imperdieterat.edu', 'test', 'Ap #474-4973 Elit Road', 14547702, '294 4117334', '294 420232', '', 'CLIENTE', 'ornare, elit elit fermentum risus, at fringilla purus mauris a nunc. In at pede. Cras vulputate velit eu sem. Pellentesque ut ipsum ac mi eleifend egestas. Sed pharetra, felis eget varius ultrices, mauris ipsum porta elit, a feugiat tellus lorem eu metus. In lorem. Donec elementum, lorem ut aliquam iaculis, lacus pede sagittis augue, eu tempor', NULL, NULL, NULL, '286-9664 Venenatis Avenue', 478, 'A', 'Molestie In Ltd', 97822362, 1),
(95, 'Marny', 'Shaffer', 'lectus@arcuSedet.co.uk', 'test', '4274 Phasellus Av.', 17515274, '294 4833391', '294 447128', '', 'CLIENTE', 'malesuada fames ac turpis egestas.', NULL, NULL, NULL, 'P.O. Box 499, 9314 Phasellus Rd.', 479, 'A', 'Rutrum Non Limited', 22014509, 1),
(96, 'Jamalia', 'Ryan', 'tincidunt@Sed.org', 'test', '1559 Egestas, St.', 25512264, '294 4327070', '294 449540', '', 'CLIENTE', 'dolor quam, elementum at, egestas a, scelerisque sed, sapien. Nunc pulvinar arcu et pede. Nunc sed orci lobortis augue scelerisque mollis. Phasellus libero mauris, aliquam eu, accumsan sed, facilisis vitae, orci. Phasellus', NULL, NULL, NULL, 'P.O. Box 133, 689 Mauris St.', 715, 'A', 'Fringilla Mi Consulting', 88509582, 1),
(97, 'Hashim', 'Alexander', 'taciti@necurnaet.ca', 'test', '338-4054 Amet Rd.', 59725885, '294 4811203', '294 477402', '', 'CLIENTE', 'elit, pretium et,', NULL, NULL, NULL, 'Ap #688-7568 Faucibus Rd.', 163, 'A', 'Maecenas Corp.', 8125640, 1),
(98, 'Summer', 'Ortiz', 'dictum.cursus.Nunc@tinciduntcongueturpis.co.uk', 'test', '7421 Aliquet Road', 66250517, '294 4294056', '294 472456', '', 'CLIENTE', 'Sed eu nibh vulputate mauris sagittis placerat. Cras dictum ultricies ligula. Nullam enim. Sed nulla ante, iaculis nec, eleifend non, dapibus rutrum, justo. Praesent luctus. Curabitur egestas nunc sed libero. Proin sed turpis nec mauris blandit mattis. Cras eget nisi dictum augue malesuada malesuada. Integer id magna et ipsum cursus vestibulum. Mauris', NULL, NULL, NULL, '515-8220 Dui, Street', 65, 'A', 'Nonummy Fusce Fermentum Corp.', 47403022, 1),
(99, 'Amir', 'Chambers', 'Suspendisse@ut.edu', 'test', 'P.O. Box 874, 4393 Eget, Rd.', 48210199, '294 4337910', '294 454983', '', 'CLIENTE', 'erat volutpat. Nulla dignissim. Maecenas ornare egestas ligula. Nullam feugiat placerat velit. Quisque varius. Nam porttitor scelerisque neque. Nullam nisl. Maecenas malesuada fringilla est. Mauris eu turpis. Nulla aliquet. Proin velit. Sed malesuada augue ut lacus. Nulla tincidunt, neque vitae semper egestas, urna justo faucibus lectus, a sollicitudin orci sem eget massa. Suspendisse eleifend. Cras sed leo. Cras vehicula aliquet libero. Integer in magna. Phasellus dolor elit, pellentesque a, facilisis non, bibendum sed, est.', NULL, NULL, NULL, '142-3128 Interdum Rd.', 299, 'A', 'Arcu Foundation', 22465522, 1),
(100, 'Quynn', 'Finch', 'habitant.morbi.tristique@massaVestibulum.com', 'test', 'P.O. Box 154, 9012 Molestie Avenue', 12149182, '294 4725844', '294 450004', '', 'CLIENTE', 'Nullam lobortis quam a felis ullamcorper viverra. Maecenas iaculis aliquet', NULL, NULL, NULL, 'P.O. Box 535, 9842 Gravida St.', 517, 'A', 'Suspendisse Ac Metus Incorporated', 34700849, 1),
(101, 'Reagan', 'Schultz', 'vestibulum.lorem@idenim.com', 'test', '6850 Accumsan St.', 14152756, '294 4538556', '294 458619', '', 'CLIENTE', 'amet, dapibus id, blandit at, nisi. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Proin vel nisl. Quisque fringilla euismod enim. Etiam gravida molestie arcu. Sed eu nibh vulputate mauris sagittis placerat. Cras dictum ultricies ligula. Nullam enim. Sed nulla ante, iaculis nec, eleifend non, dapibus rutrum, justo. Praesent', NULL, NULL, NULL, '684-8614 Est Road', 797, 'A', 'Montes Nascetur Ridiculus Industries', 70928451, 1),
(102, 'Kaye', 'Page', 'ornare.lectus.justo@rutrumeu.edu', 'test', '2816 Sollicitudin St.', 69723346, '294 4014746', '294 460501', '', 'CLIENTE', 'et magnis dis parturient montes, nascetur ridiculus mus. Proin vel arcu eu odio tristique pharetra. Quisque ac libero nec ligula consectetuer rhoncus. Nullam velit dui, semper et, lacinia vitae, sodales at, velit. Pellentesque ultricies dignissim lacus. Aliquam rutrum lorem ac risus. Morbi metus. Vivamus euismod urna. Nullam lobortis quam a felis ullamcorper viverra. Maecenas iaculis aliquet diam. Sed diam lorem, auctor quis, tristique ac, eleifend vitae, erat. Vivamus nisi. Mauris nulla. Integer urna. Vivamus molestie dapibus ligula. Aliquam erat volutpat. Nulla dignissim. Maecenas ornare egestas ligula. Nullam feugiat placerat velit. Quisque varius.', NULL, NULL, NULL, '893 Gravida Av.', 475, 'A', 'Mus Aenean Corporation', 47688600, 1);

--
-- Truncar tablas antes de insertar `zonas`
--

TRUNCATE TABLE `zonas`;
--
-- Volcado de datos para la tabla `zonas`
--

INSERT INTO `zonas` (`zona_id`, `sistema_alarmas_sistema_alarma_id`, `nombre_zona`, `observaciones_zona`) VALUES
(22, 8, 'Living', 'Puerta y Living'),
(23, 9, 'Entrada', 'Entrada al local'),
(24, 9, 'Trastienda', 'Con puerta trasera'),
(25, 10, 'Aberturas', 'Todas las aberturas'),
(26, 11, 'Living/Comedor', 'con entrada'),
(27, 11, 'Dormitorio 1', 'con ventana'),
(28, 11, 'Baño', '-'),
(29, 12, 'Entrada', ''),
(30, 13, 'Patio Delantero', ''),
(31, 13, 'Patio trasero', ''),
(32, 14, 'Sala de Estar', ''),
(33, 14, 'Cocina', '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
